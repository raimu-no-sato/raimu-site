<?php
/**
 * 来夢の里 Cocoon子テーマ functions.php
 */

/* 親テーマのスタイルを読み込む */
add_action( 'wp_enqueue_scripts', 'raimu_child_enqueue_styles' );
function raimu_child_enqueue_styles() {
    wp_enqueue_style(
        'cocoon-style',
        get_template_directory_uri() . '/style.css'
    );
    wp_enqueue_style(
        'raimu-child-style',
        get_stylesheet_uri(),
        array( 'cocoon-style' ),
        wp_get_theme()->get( 'Version' )
    );
}

/* =====================================================
   ページ幅をフルワイドにする（コンテンツエリア）
   ===================================================== */
add_filter( 'body_class', 'raimu_add_body_class' );
function raimu_add_body_class( $classes ) {
    $classes[] = 'raimu-site';
    return $classes;
}

/* =====================================================
   カスタム投稿タイプ：求人（job）
   ===================================================== */
add_action( 'init', 'raimu_register_job_post_type' );
function raimu_register_job_post_type() {
    register_post_type( 'job', array(
        'labels' => array(
            'name'          => '求人情報',
            'singular_name' => '求人',
            'add_new_item'  => '新しい求人を追加',
            'edit_item'     => '求人を編集',
            'view_item'     => '求人を表示',
            'search_items'  => '求人を検索',
        ),
        'public'        => true,
        'has_archive'   => true,
        'menu_icon'     => 'dashicons-businessman',
        'menu_position' => 5,
        'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'rewrite'       => array( 'slug' => 'jobs' ),
        'show_in_rest'  => true,
    ) );
}

/* =====================================================
   管理画面：不要なメニューを非表示
   ===================================================== */
add_action( 'admin_menu', 'raimu_remove_admin_menus' );
function raimu_remove_admin_menus() {
    // 必要に応じてコメントを外す
    // remove_menu_page( 'edit-comments.php' ); // コメント
}

/* =====================================================
   wp_head にGoogleフォントを追加（バックアップ）
   ===================================================== */
add_action( 'wp_head', 'raimu_add_google_fonts' );
function raimu_add_google_fonts() {
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
    echo '<link href="https://fonts.googleapis.com/css2?family=Noto+Serif+JP:wght@400;600;700&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">';
}

/* =====================================================
   抜粋の文字数を調整
   ===================================================== */
add_filter( 'excerpt_length', function() { return 80; } );
add_filter( 'excerpt_more',   function() { return '…'; } );

/* =====================================================
   ウィジェットエリアの登録
   ===================================================== */
add_action( 'widgets_init', 'raimu_register_sidebars' );
function raimu_register_sidebars() {
    register_sidebar( array(
        'name'          => '採用情報サイドバー',
        'id'            => 'sidebar-recruit',
        'description'   => '採用情報ページ用サイドバー',
        'before_widget' => '<div class="raimu-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="raimu-widget-title">',
        'after_title'   => '</h3>',
    ) );
}
